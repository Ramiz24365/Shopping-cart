const Reg=require('../models/reg')
const bcrypt=require('bcrypt')



exports.regsiter=async(req,res)=>{
    //console.log(req.body)
    const{username,password}=req.body
    const convertedpass=await bcrypt.hash(password,10)
    //console.log(convertedpass)
    const usercheck=await Reg.findOne({username:username})
    //console.log(usercheck)
    try{
        if(usercheck==null){
            const record= new Reg({username:username,password:convertedpass})
            record.save()
            res.json({
                status:201,
                apiData:record,
                massage:` ${username} successfully account has been created`
            })
        }
        else{
            res.json({
                status:400,
                massage:`${username} is already taken`
            })
        }  
    }
    catch(error){
        res.json({
            status:400,
            massage:error.massage
        })

    }
}

exports.login=async(req,res)=>{
    //console.log(req.body)
    const{username,password}=req.body
    try{
        const record=await Reg.findOne({username:username})
        if(record!==null){
            const passwordcheck=await bcrypt.compare(password,record.password)
            //console.log(passwordcheck)
            if(passwordcheck){
                res.json({
                    status:200,
                    apiData:record.username,
                })
            }
            else{
                res.json({
                    status:400,
                    massage:"wrong password"
                })
            }
        }
        else{
            res.json({
                status:400,
                massage:"wrong username"
            })
        }
    }
    catch(error){
        res.json({
            status:400,
            massage:error.massage
        })
    }

}