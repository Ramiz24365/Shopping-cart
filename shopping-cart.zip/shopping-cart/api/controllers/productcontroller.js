const { json } = require('express')
const Product = require('../models/products')


exports.addproducts = (req, res) => {
    //console.log(req.body)
    //console.log(req.file)
    const { name, desc, price, qty } = req.body
    const imagename = req.file.filename
    try {
        const record = new Product({ name: name, desc: desc, img: imagename, price: price, qty: qty, })
        record.save()
        res.json({
            status: 201,
            massage: "successfully added product"
        })
    }
    catch (error) {
        res.json({
            status: 400,
            massage: error.massage
        })
    }
}

exports.allproducts = async (req, res) => {
    try {
        const record = await Product.find()
        res.json({
            status: 200,
            apiData: record
        })
    }
    catch (error) {
        res.json({
            status: 500,
            massage: error.massage
        })
    }
}

exports.singleproduct = async (req, res) => {
    //console.log(req.params.id)
    try {
        const id = req.params.id
        const record = await Product.findById(id)
        //console.log(record)
        res.json({
            status: 200,
            apiData: record
        })
    }
    catch (error) {
        res.json({
            status: 500,
            massage: error.massage
        })
    }

}

exports.productupdate = async (req, res) => {
    //console.log(req.body)
    //console.log(req.params.id)
    //console.log(req.file)
    const { name, desc, price, qty, status } = req.body
    const id = req.params.id
    try {
        if (req.file) {
            const filename = req.file.filename
            await Product.findByIdAndUpdate(id, { name: name, desc: desc, img: filename, price: price, qty: qty, status: status })
        }
        else {
            await Product.findByIdAndUpdate(id, { name: name, desc: desc, price: price, qty: qty, status: status })
        }
        res.json({
            status: 200,
            massage: 'successfully updated'
        })
    }
    catch (error) {
        res.json({
            status: 400,
            massage: error.massage
        })
    }
}

exports.stockproducts=async(req,res)=>{
    try{
        const record=await Product.find({status:"IN-STOCK"})
        res.json({
           status:200,
           apiData:record
        })
    }
    catch(error){
        res.json({
            status:500,
            massage:error.massage
        })
    }
}
exports.cart=async(req,res)=>{
    //console.log(req.body)
    try{
        const{ids}=req.body
        const record=await Product.find({_id:{$in:ids}})
        res.json({
            status:200,
            apiData:record
        })
    }
    catch(error){
        res,json({
            status:500,
            massage:error.massage
        })
    }

}
exports.checkout=(req,res)=>{
    console.log(req.body)
    console.log(req.params.username)
}

exports.deleteproduct=async(req,res)=>{
    //console.log(req.params.id)
    try{
        const id=req.params.id
        await Product.findByIdAndDelete(id)
        res.json({
            status:200,
            massage:"successsfully deleted"
        })
    }
    catch(error){
        res.json({
            status:500,
            massage:error.massage
        })
    }
}
exports.productdetails=async(req,res)=>{
    //console.log(req.params.id)
    try{
        const id=req.params.id
        const record=await Product.findById(id)
        //console.log(record)
        res.json({
            status:200,
            apiData:record
        })
    }
    catch(error){
        res.json({
            status:400,
            massage:error.massage
        })
    }
}