const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const productc=require('../controllers/productcontroller')
const upload=require('../helpers/multer')

router.post('/register',regc.regsiter)
router.post('/login',regc.login)
router.post('/adminaddproducts',upload.single('img'),productc.addproducts)
router.get('/allproducts',productc.allproducts)
router.get('/singleproduct/:id',productc.singleproduct)
router.put('/productupdate/:id',upload.single('img'),productc.productupdate)
router.get('/stockproducts',productc.stockproducts)
router.post('/cart',productc.cart)
router.post('/checkout/:username',productc.checkout)
router.delete('/adminproductdelete/:id',productc.deleteproduct)
router.get('/productdetails/:id',productc.productdetails)


module.exports=router
