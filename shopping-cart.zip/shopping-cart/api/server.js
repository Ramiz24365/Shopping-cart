const express=require('express')
const app=express()
app.use(express.json())  /* <--convert data into json format */
require('dotenv').config()  /* <--calling .env file */
const apiRouter=require('./routers/apirouter')
const mongoose=require('mongoose')
mongoose.connect(`${process.env.DB_URL}/${process.env.DB_NAME}`)

app.use('/api',apiRouter)
app.listen(process.env.PORT,()=>{console.log(` Ramiz server is running on port ${process.env.PORT} `)})