import { useContext } from "react";
import { Contextapi } from "../Contextapi";
import { Link } from "react-router-dom";

function Productstructure(props) {
   const{cart,setCart}= useContext(Contextapi)
    const{product}=props
    function handlecart(e,productid){
        //console.log(productid)
        let _cart={...cart}
        if(!_cart.item){
            _cart.item={}
        }
        if(!_cart.item[productid]){
            _cart.item[productid]=1
        }
        else{
            _cart.item[productid] +=1
        }
        if(!_cart.totalitems){
            _cart.totalitems=1
        }
        else{
            _cart.totalitems +=1
        }
        setCart(_cart)
        //console.log(cart)
    }
    return (
        <section>
            <div classNameName="container">
                <div classNameName="row">
                    <div classNameName="col-md-3">
                        <div className="card align-items-center text-center" style={{ width: "18rem",height:"18rem" }} >
                            <img style={{width:"200px"}} src={`./${product.img}`} className="card-img-top mt-2" alt="..."></img>
                            <div className="card-body">
                                <h5 className="card-title">{product.name}</h5>         
                                <p className="card-text"> Price :<span> {product.price} <i class="bi bi-currency-rupee"></i></span></p>           
                                <button className="btn btn-primary me-2" onClick={(e)=>{handlecart(e,product._id)}}><span> <i class="bi bi-cart3"></i> </span>Add Cart</button>
                                <Link to={`/productdetails/${product._id}`}><button className="btn btn-primary">Deatils</button></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Productstructure;