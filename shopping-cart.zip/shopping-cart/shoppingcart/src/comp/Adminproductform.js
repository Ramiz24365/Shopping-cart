import { useState } from "react";
import Left from "./Left";
function Adminproductsform() {
    const [name, setName] = useState('')
    const [desc, setDesc] = useState('')
    const [price, setPrice] = useState('')
    const [qty, setQty] = useState('')
    const [productimg, setProductImg] = useState('')
    const[massage,setMassage]=useState('')
    function handleform(e) {
        e.preventDefault();
        //console.log(name,price,desc,qty,productimg)
        let Data=new FormData()
        Data.append('name',name)
        Data.append('desc',desc)
        Data.append('price',price)
        Data.append('qty',qty)
        Data.append('img',productimg)
        fetch('/api/adminaddproducts',{
            method:"POST",
            body:Data
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===201){
              setMassage(data.massage)  
            }
            else{
               setMassage(data.massage)
            }
        })
    }
    return (
        <section id="dashboard">
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-2">
                        <Left />
                    </div>
                    <div className="col-md-10">
                        <h3 className="text-center">Add new product here</h3>
                        <p>{massage}</p>
                        <form onSubmit={(e) => { handleform(e) }}>
                            <label>Product Name</label>
                            <input type="text" className="form-control" value={name} onChange={(e)=>{setName(e.target.value)}}></input>
                            <label>Product Description</label>
                            <input type="text" className="form-control"  value={desc} onChange={(e)=>{setDesc(e.target.value)}}></input>
                            <label>Product Price</label>
                            <input type="number" className="form-control" value={price} onChange={(e)=>{setPrice(e.target.value)}}></input>
                            <label>Product Quantity</label>
                            <input type="number" className="form-control" value={qty} onChange={(e)=>{setQty(e.target.value)}}></input>
                            <label>Product Image</label>
                            <input type="file" className="form-control" onChange={(e)=>{setProductImg(e.target.files[0])}}></input>
                            <button type="submit" className="btn btn-success form-control mt-2">Add</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}


export default Adminproductsform;