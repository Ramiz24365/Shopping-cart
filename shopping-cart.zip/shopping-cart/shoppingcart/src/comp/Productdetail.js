import { useContext, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Contextapi } from "../Contextapi";

function Productdetail() {
    const { cart, setCart } = useContext(Contextapi)
    const [massage, setMassage] = useState('')
    const [product, setProduct] = useState('')
    const { id } = useParams()
    useEffect(() => {
        fetch(`/api/productdetails/${id}`).then((result) => { return result.json() }).then((data) => {
            console.log(data)
            if (data.status === 200) {
                setProduct(data.apiData)
            }
            else {
                setMassage(data.massage)
            }
        })
    }, [])
    function handlecart(e, productid) {
        console.log(productid)
        let _cart = { ...cart }
        if (!_cart.item) {
            _cart.item = {}
        }
        if (!_cart.item[productid]) {
            _cart.item[productid] = 1
        }
        else {
            _cart.item[productid] += 1
        }
        if (!_cart.totalitems) {
            _cart.totalitems = 1
        }
        else {
            _cart.totalitems += 1
        }
        setCart(_cart)
        //console.log(cart)
    }
    return (
        <section id="details">
            <div className="container mt-5">
                <div className="row">
                    <div className="col-md-8">
                        <div className="productimage">
                        <img src={`/${product.img}`} alt="" className="img-fluid"></img>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <h2>{product.name}</h2>
                        <p className="mt-2"> Price:- <span> {product.price} <i class="bi bi-currency-rupee"></i>/-</span></p>
                        <div className="align-items-center mt-5 mb-5">
                            <button className="btn btn-dark me-2" onClick={(e) => { handlecart(e, product._id) }}><span> <i class="bi bi-cart3"></i> </span>Add Cart</button>
                            <button className="btn btn-success">{product.status}</button>
                        </div>
                        <h3>Product Details</h3>
                        <p>{product.desc}</p>
                    </div>
                </div>
            </div>

        </section>
    );
}

export default Productdetail;