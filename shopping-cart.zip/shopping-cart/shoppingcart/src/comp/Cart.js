import { useContext, useEffect, useState } from "react";
import { Contextapi } from "../Contextapi";
import { Link, useNavigate } from "react-router-dom";

function Cart() {
    let totalamount = 0
    let navigate = useNavigate()
    const [massage, setMassage] = useState('')
    const [products, setProducts] = useState([])
    const { cart, setCart, loginname } = useContext(Contextapi)
    useEffect(() => {
        if (!cart.item) {
            return
        }
        fetch('/api/cart', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ids: Object.keys(cart.item) })
        }).then((result) => { return result.json() }).then((data) => {
            //console.log(data)
            if (data.status === 200) {
                setProducts(data.apiData)
            }
            else {
                setMassage(data.massage)
            }
        })
    }, [])
    function handleqty(id) {
        return cart.item[id]
    }
    function handleincrement(e, id, qty) {
        let currentqty = handleqty(id)
        if (currentqty === qty) {   /* <---for maximum quantity equal to stock quantity in database */
            alert('You have reached to maximum quantity')
            return
        }
        let _cart = { ...cart }
        _cart.item[id] = currentqty + 1  /* <---increase quantity */
        _cart.totalitems += 1        /* <-----increase total items quantity   */
        setCart(_cart)
    }
    function handledecrement(e, id) {
        let currentqty = handleqty(id)
        if (currentqty === 1) {   /* <---condition for quantity does not have zero minimum is 1 */
            alert('You have rached to minimum quantity')
            return
        }
        let _cart = { ...cart }
        _cart.item[id] = currentqty - 1  /* <---decrease quantity */
        _cart.totalitems -= 1        /* <-----decrease total items quantity  */
        setCart(_cart)
    }
    function handleprice(id, price) {
        let tprice = handleqty(id) * price  /* <---calculate each product price based on quantity */
        totalamount += tprice              /* <----calculate totalamount of cart item to pay */
        return tprice
    }
    function handlecartdelete(e,id){
        let current_qnty=handleqty(id)
        let _cart={...cart}
        delete _cart.item[id]
        _cart.totalitems -= current_qnty
        setCart(_cart)
    }
    function handlecheckout(e) {
        fetch(`/api/checkout/${loginname}`, {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(cart.item)
        })
        setCart('')
        navigate('/products')
    }
    return (
        <>
            <h2 className="text-center">Cart</h2>
            <section id="cart">
                {products.length !== 0 ?
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <table className="table table-dark">
                                    <thead>
                                        <tr>
                                            <th>S.NO</th>
                                            <th>Product Name</th>
                                            <th>Product Quantity</th>
                                            <th>Product Price</th>
                                            <th>Product Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {products.map((result, sn) => (
                                            <tr className="table table-light">
                                                <td>{sn + 1}</td>
                                                <td>{result.name}</td>
                                                <td><button className="btn btn-outline-success" onClick={(e) => { handleincrement(e, result._id, result.qty) }}>+</button>    {handleqty(result._id)}    <button className="btn btn-outline-danger" onClick={(e) => { handledecrement(e, result._id) }}>-</button></td>
                                                <td>{handleprice(result._id, result.price)} <i class="bi bi-currency-rupee"></i></td>
                                                <td><button onClick={(e)=>{handlecartdelete(e,result._id)}}><i class="bi bi-trash3-fill"></i></button></td>
                                            </tr>
                                        ))}
                                        <tr>
                                            <td colSpan='5'>Total Amount to Pay  :-  <span>{totalamount} <i class="bi bi-currency-rupee"></i> /-</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div className="text-center">
                                    <button className="checkoutbtn" onClick={(e) => { handlecheckout(e) }}> Proceed To Check Out</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    :
                    <section id="emptycart">
                        <div className="container">
                            <div className="row">
                                <div className="col-md-12 text-center">
                                    <img src="./images/emptycart.png" alt="" className="img-fluid"></img>
                                    <p style={{color:"#7C7D7E "}}>Before Proceed to Checkout, You must add Some Products to Your Cart.</p>
                                    <p style={{color:"#7C7D7E "}}>You Will Find a lot of intresting Products on "Shopping" Page.</p>
                                    <Link to='/products'><button className="checkoutbtn"><i class="bi bi-shop" style={{fontSize:"25px"}}></i> Return to Shop </button></Link>
                                </div>
                            </div>
                        </div>
                    </section>
                }
            </section>
        </>
    );
}

export default Cart;