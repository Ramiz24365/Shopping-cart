import { Link } from "react-router-dom";

function Left() {
    return (
        <div class="sidebar">
            <br></br><br></br>
            <Link to='/dashboard'><button className="btn btn-dark form-control">Dashboard</button></Link>
            <Link to='/adminproducts'><button className="btn btn-dark form-control mt-2">Products Management</button></Link>
            <Link to='/adminnewproduct'><button className="btn btn-dark form-control mt-2">Add New Products</button></Link>
        </div>
    );
}

export default Left;