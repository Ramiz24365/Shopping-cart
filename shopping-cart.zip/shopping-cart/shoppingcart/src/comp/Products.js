import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Productstructure from "./Productstructure";

function Products() {
    const [massage, setMassage] = useState('')
    const [products, setProducts] = useState([])

    useEffect(() => {
        fetch('/api/stockproducts').then((result) => { return result.json() }).then((data) => {
            //console.log(data)
            if (data.status === 200) {
                setProducts(data.apiData)
            }
            else {
                setMassage(data.massage)
            }
        })
    }, [])
    return (
        <div id="products">
            {products.map((result, key) => (
                <Productstructure product={result} />
            ))}
        </div>
    );
}

export default Products;