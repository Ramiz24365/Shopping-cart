import { Link, useNavigate } from "react-router-dom";
import Left from "./Left";
import { useContext, useEffect, useState } from "react";
import { Contextapi } from "../Contextapi";

function Adminproducts() {
    const navigate=useNavigate()
    const{loginname}=useContext(Contextapi)
    const [massage, setMassage] = useState('')
    const [products, setProducts] = useState([])
        useEffect(() => {
            fetch('/api/allproducts').then((result) => { return result.json() }).then((data) => {
                //console.log(data)
                if (data.status === 200) {
                    setProducts(data.apiData)
                    if(!loginname){
                        navigate('/')
                    }
                    else{
                        
                    }
                }
                else {
                    setMassage(data.massage)
                }
            })
        }, [])

        function handleproductdelete(e,id){
            fetch(`/api/adminproductdelete/${id}`,{
                method:"DELETE"
            }).then((result)=>{return result.json()}).then((data)=>{
                //console.log(data)
                if(data.status===200){
                    navigate('/adminproducts')
                }
                else{
                    setMassage(data.massage)
                }
            })
        }

    return (
        <section id="dashboard">
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-2">
                        <Left />
                    </div>
                    <div className="col-md-10">
                        <h3 className="text-center">Product Management</h3>
                        <p>{massage}</p>
                        <table className="table table-secondary">
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Product Name</th>
                                    <th>Products Description</th>
                                    <th>Product Image</th>
                                    <th>Product Price</th>
                                    <th>Product Quantity</th>
                                    <th>Product status</th>
                                    <th>Product Update</th>
                                    <th>Product Delete</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                {products.map((result, key) => (
                                    <tr key={result._id}>
                                        <td>{key+1}</td>
                                        <td>{result.name}</td>
                                        <td>{result.desc}</td>
                                        <td>{result.img}</td>
                                        <td>{result.price}</td>
                                        <td>{result.qty}</td>
                                        <td>{result.status}</td>
                                        <td><Link to={`/adminproductupdate/${result._id}`}><button className="btn btn-outline-primary">Update</button></Link></td>
                                        <td><button onClickCapture={(e)=>{handleproductdelete(e,result._id)}} className="btn btn-outline-danger">Delete</button></td>
                                    </tr>
                                ))}

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Adminproducts;