import { Navigate, useNavigate, useParams } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";

function Adminproductupdate() {
    let navigate=useNavigate()
    const [name, setName] = useState('')
    const [desc, setDesc] = useState('')
    const [price, setPrice] = useState('')
    const [qty, setQty] = useState('')
    const [productimg, setProductImg] = useState('')
    const [massage,setMassage]=useState('')
    const [status, setStatus] = useState('')
    const{id}=useParams()
    useEffect(()=>{
        fetch(`/api/singleproduct/${id}`).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setName(data.apiData.name)
                setDesc(data.apiData.desc)
                setPrice(data.apiData.price)
                setQty(data.apiData.qty)
                setProductImg(data.apiData.productimg)
                setStatus(data.apiData.status)
            }
            else{
                setMassage(data.massage)
            }
        })
    },[])
    function handleform(e){
        e.preventDefault()
        //console.log(name,desc,price,qty,status)
        //console.log(productimg)
        const data=new FormData()
        data.append('name',name)
        data.append('desc',desc)
        data.append('price',price)
        data.append('qty',qty)
        data.append('img',productimg)
        data.append('status',status)
        fetch(`/api/productupdate/${id}`,{
            method:'PUT',
            body:data
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
               navigate('/adminproducts')    
            }
            else{
                setMassage(data.massage)
            }
        })
    }
    return (
        <section id="dashboard">
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-2">
                        <Left />
                    </div>
                    <div className="col-md-10">
                        <h1>Update product</h1>
                        <p>{massage}</p>
                        <form onSubmit={(e)=>{handleform(e)}}>
                            <label>Product Name</label>
                            <input type="text" className="form-control" value={name} onChange={(e)=>{setName(e.target.value)}}></input>
                            <label>Product Description</label>
                            <input type="text" className="form-control" value={desc} onChange={(e)=>{setDesc(e.target.value)}} ></input>
                            <label>Product Price</label>
                            <input type="number" className="form-control" value={price} onChange={(e)=>{setPrice(e.target.value)}}></input>
                            <label>Product Quantity</label>
                            <input type="number" className="form-control" value={qty} onChange={(e)=>{setQty(e.target.value)}} ></input>
                            <label> Product Status</label>
                            <select className="form-select" value={status} onChange={(e)=>{setStatus(e.target.value)}}>
                                <option value='IN-STOCK'>IN-STOCK</option>
                                <option value='OUT-STOCK'>OUT-STOCK</option>
                            </select>
                            <label>Product Image</label>
                            <input type="file" className="form-control" onChange={(e)=>{setProductImg(e.target.files[0])}}></input>
                            <button type="submit" className="btn btn-success form-control mt-2">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Adminproductupdate;