import Left from "./Left";

function Dashboard() {
    return (
        <section id="dashboard">
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-3">
                        <Left />
                    </div>
                    <div className="col-md-9">
                        <h1>Shopping-cart Admin Dashboard</h1>
                        <div className="content">
                            <img src="./images/dashboard-img.png" alt="" className="img-fluid"></img>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Dashboard;