import { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Contextapi } from "../Contextapi";

function Header() {
    const navigate = useNavigate()
    const { loginname, setLoginname,cart } = useContext(Contextapi)
    function handlelogout(e) {
        localStorage.removeItem('loginname')
        setLoginname(localStorage.getItem('loginname'))
        navigate('/')
    }
    return (
        <section id='header'>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-12">
                    {loginname ?
                    <>
                        <nav className="navbar navbar-expand-lg bg-light">
                            <div className="container-fluid">
                                        <Link className="navbar-brand" to=""><i class="bi bi-cart-fill"></i> Shoes Hub</Link>
                                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                          <i class="bi bi-list"></i>
                                        </button>
                                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                                            <ul className="navbar-nav ms-auto justify-content-center align-items-center">

                                                <li className="nav-item">
                                                    <Link className="nav-link active" aria-current="page" to="">Home</Link>
                                                </li>
                                                <li className="nav-item">
                                                    <Link className="nav-link active" aria-current="page" to="/products">Products</Link>
                                                </li>
                                                <li className="nav-item">
                                                    <Link className="nav-link" to="/cart"><i class="bi bi-cart4"></i>{!cart.totalitems?0: cart.totalitems}</Link>
                                                </li>
                                                <li className="nav-item">
                                                    <button className="user-profile"><i class="bi bi-person-circle"></i> {loginname}</button>
                                                </li>
                                                <li className="nav-item">
                                                    <button className="btn btn-danger" onClick={(e) => { handlelogout(e) }}><i class="bi bi-box-arrow-right"></i> Log out</button>
                                                </li>
                                            </ul>
                                        </div>
                            </div>
                        </nav>
                        </>
                        :
                        <>
                        </>
}
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Header;