import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Contextapi } from "../Contextapi";

function Login() {
    const navigate=useNavigate()
    const{setLoginname}=useContext(Contextapi)
    const[username,setUsername]=useState("")
    const[password,setPassword]=useState("")
    const[massage,setMassage]=useState('')
    function handleform(e){
        e.preventDefault()
        //console.log(username,password)
        const formdata={username,password}
        fetch('/api/login',{
            method:'POST',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                localStorage.setItem('loginname',data.apiData)
                setLoginname(localStorage.getItem('loginname'))
                if(data.apiData==='admin@gmail.com'){
                    navigate('/dashboard')
                }
                else{
                    navigate('/products')
                }
            }
            else{
                setMassage(data.massage)
            }
        })
    }
    return ( 
        <section id="login">
        <div className="container">
            <div className="row">
                <div className="col-md-6 left-side">
                    <img src="./images/login1.png" alt="" className="img-fluid mb-2" width="400"/>
                    <h2>Be Verfied</h2>
                    <p>Please Login with Your Registered Email and Password</p>
                </div>
                <div className="col-md-6 right-side">
                    <div className="text-center">
                        <img src="./images/welcome.png" alt="" className="img-fluid" width="400px"/>
                    </div>
                    <p>{massage}</p>
                    <form onSubmit={(e)=>{handleform(e)}}>
                        <input type="email" name="" id="" required value={username} onChange={(e)=>{setUsername(e.target.value)}} placeholder="Email address" className="form-control form-control-lg bg-light mt-4"/>
                        <input type="password" name="" id="" required  value={password} onChange={(e)=>{setPassword(e.target.value)}} placeholder="Password" className="form-control form-control-lg bg-light mt-3"/>
                        <button type="submit" className="btn btn-dark btn-lg form-control mt-3">Login</button>
                    </form>
                    <Link to='/reg'><button className="btn  btn-light btn-lg form-control mt-3">Don't have account? Register here</button></Link>
                </div>
            </div>
        </div>
    </section>
     );
}

export default Login;